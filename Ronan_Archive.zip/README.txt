This file describes the files present in this directory and their uses 

mastergxlha.py  : creates a full list of galaxies, including satellites and centrals, and prints out the position, radial velocity,
                  H-alpha luminosity, and the object radius

mastergxlco.py  : creates a full list of galaxies, including satellites and centrals, and prints out the position, radial velocity,
                  CO (1-0) luminosity, and the object radius

mastergxlnhm.py : The same as mastergxlco.py, but not considering halo motions

mastergxlst.py  : The same as mastergxlco.py, but not considering satellite motions

mastergxlst.py  : The same as mastergxlco.py, but not considering any bulk motions either of the halo or within the halo (for satellites)



